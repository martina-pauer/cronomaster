# Folder 'packs' for packages for different linux distros
* `flatpak` for many distros like Linux Mint or Fedora between the more famous.
* `snap`for independents packages for Ubuntu and be published in the Snaps Store
* `deb` for distros based on Debian than don't use flatpak yet
* `rpm` for Red Hat distros like Fedora, RHEL and CentOS
* `.pkg.tar.zst` for Arch Linux based distros like Arch Linux or Manjaro with `pacman`packages manager